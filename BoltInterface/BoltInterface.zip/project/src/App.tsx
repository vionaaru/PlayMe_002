import React, { useState } from 'react';
import { Sparkles } from 'lucide-react';
import { ChatMessage } from './components/ChatMessage';
import { ChatInput } from './components/ChatInput';
import { Message } from './types/message';

const INITIAL_MESSAGE = "Привет! Я рада тебя видеть. Можешь отправить мне сообщение или поделиться фотографией 📸";

function App() {
  const [messages, setMessages] = useState<Message[]>([
    { id: 1, text: INITIAL_MESSAGE, isBot: true }
  ]);
  const [isLoading, setIsLoading] = useState(false);

  const handleSendMessage = async (message: string, image?: string) => {
    const newMessage: Message = {
      id: messages.length + 1,
      text: message,
      isBot: false,
      image
    };
    setMessages(prev => [...prev, newMessage]);
    setIsLoading(true);

    setTimeout(() => {
      const responses = [
        "Какая красивая фотография! Расскажи мне о ней подробнее...",
        "Мне нравится твой художественный вкус ✨",
        "Это фото вызывает особые эмоции...",
        "Интересный ракурс! Ты увлекаешься фотографией?",
        "Очень атмосферно... Что вдохновило тебя поделиться этим?"
      ];
      const regularResponses = [
        "Интересно... Расскажи мне больше о себе",
        "Мне нравится твой подход к общению",
        "Какие у тебя планы на будущее?",
        "Твои мысли очень глубокие...",
        "Я чувствую, что мы с тобой похожи"
      ];

      const botResponse: Message = {
        id: messages.length + 2,
        text: image ? responses[Math.floor(Math.random() * responses.length)] : 
                     regularResponses[Math.floor(Math.random() * regularResponses.length)],
        isBot: true
      };
      setMessages(prev => [...prev, botResponse]);
      setIsLoading(false);
    }, 1000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 to-gray-800 flex flex-col">
      {/* Header */}
      <header className="bg-gray-800/50 border-b border-gray-700">
        <div className="max-w-4xl mx-auto px-4 py-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-purple-700 flex items-center justify-center">
            <Sparkles className="w-6 h-6 text-purple-200" />
          </div>
          <h1 className="text-xl font-semibold text-purple-100">PlayMe</h1>
        </div>
      </header>

      {/* Chat Messages */}
      <div className="flex-1 overflow-y-auto">
        <div className="max-w-4xl mx-auto">
          <div className="divide-y divide-gray-700/50">
            {messages.map(message => (
              <div key={message.id} className="message-animate">
                <ChatMessage
                  message={message.text}
                  isBot={message.isBot}
                  image={message.image}
                />
              </div>
            ))}
            {isLoading && (
              <div className="p-4 bg-gray-800/30">
                <div className="flex gap-2 items-center">
                  <div className="w-2 h-2 bg-purple-500 rounded-full animate-bounce" />
                  <div className="w-2 h-2 bg-purple-500 rounded-full animate-bounce [animation-delay:0.2s]" />
                  <div className="w-2 h-2 bg-purple-500 rounded-full animate-bounce [animation-delay:0.4s]" />
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Chat Input */}
      <ChatInput onSend={handleSendMessage} disabled={isLoading} />
    </div>
  );
}

export default App;