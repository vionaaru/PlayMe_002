import React, { useState, useRef } from 'react';
import { Send, Image as ImageIcon, X } from 'lucide-react';

interface ChatInputProps {
  onSend: (message: string, image?: string) => void;
  disabled?: boolean;
}

export function ChatInput({ onSend, disabled }: ChatInputProps) {
  const [message, setMessage] = useState('');
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if ((message.trim() || imagePreview) && !disabled) {
      onSend(message, imagePreview || undefined);
      setMessage('');
      setImagePreview(null);
    }
  };

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const clearImage = () => {
    setImagePreview(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <form onSubmit={handleSubmit} className="border-t border-gray-700 bg-gray-800/50 p-4">
      {imagePreview && (
        <div className="max-w-4xl mx-auto mb-4 relative">
          <img
            src={imagePreview}
            alt="Preview"
            className="max-w-[200px] rounded-lg"
          />
          <button
            type="button"
            onClick={clearImage}
            className="absolute -top-2 -right-2 bg-gray-800 rounded-full p-1 hover:bg-gray-700 transition-colors"
          >
            <X className="w-4 h-4 text-gray-300" />
          </button>
        </div>
      )}
      <div className="flex gap-4 max-w-4xl mx-auto">
        <input
          type="text"
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          placeholder="Напиши мне что-нибудь..."
          className="flex-1 rounded-lg bg-gray-700 border-gray-600 text-gray-100 px-4 py-2 
                   focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent
                   placeholder-gray-400"
          disabled={disabled}
        />
        <input
          type="file"
          accept="image/*"
          onChange={handleImageSelect}
          ref={fileInputRef}
          className="hidden"
          id="image-input"
        />
        <label
          htmlFor="image-input"
          className="bg-gray-700 text-purple-100 px-4 py-2 rounded-lg hover:bg-gray-600 
                   cursor-pointer transition-colors flex items-center justify-center"
        >
          <ImageIcon className="w-5 h-5" />
        </label>
        <button
          type="submit"
          disabled={disabled || (!message.trim() && !imagePreview)}
          className="bg-purple-700 text-purple-100 px-4 py-2 rounded-lg hover:bg-purple-600 
                   focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-offset-2 
                   focus:ring-offset-gray-800 disabled:opacity-50 disabled:cursor-not-allowed 
                   transition-colors"
        >
          <Send className="w-5 h-5" />
        </button>
      </div>
    </form>
  );
}