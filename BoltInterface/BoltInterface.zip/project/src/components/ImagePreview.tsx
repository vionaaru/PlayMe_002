import React, { useState } from 'react';
import { X } from 'lucide-react';
import { TransformWrapper, TransformComponent } from 'react-zoom-pan-pinch';

interface ImagePreviewProps {
  src: string;
  onClose: () => void;
}

export function ImagePreview({ src, onClose }: ImagePreviewProps) {
  return (
    <div className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center">
      <button
        onClick={onClose}
        className="absolute top-4 right-4 text-white hover:text-purple-300 transition-colors"
      >
        <X className="w-6 h-6" />
      </button>
      <TransformWrapper>
        <TransformComponent>
          <img
            src={src}
            alt="Preview"
            className="max-w-full max-h-[90vh] object-contain"
          />
        </TransformComponent>
      </TransformWrapper>
    </div>
  );
}