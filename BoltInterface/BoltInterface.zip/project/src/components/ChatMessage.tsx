import React, { useState } from 'react';
import ReactMarkdown from 'react-markdown';
import { Sparkles, User } from 'lucide-react';
import { ImagePreview } from './ImagePreview';

interface ChatMessageProps {
  message: string;
  isBot: boolean;
  image?: string;
}

export function ChatMessage({ message, isBot, image }: ChatMessageProps) {
  const [showImagePreview, setShowImagePreview] = useState(false);

  return (
    <>
      <div className={`flex gap-4 p-4 ${isBot ? 'bg-gray-800/30' : 'bg-gray-800/10'}`}>
        <div className="flex-shrink-0">
          {isBot ? (
            <div className="w-8 h-8 rounded-lg bg-purple-700 flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-purple-200" />
            </div>
          ) : (
            <div className="w-8 h-8 rounded-lg bg-gray-600 flex items-center justify-center">
              <User className="w-5 h-5 text-gray-200" />
            </div>
          )}
        </div>
        <div className="flex-1 prose prose-invert prose-purple max-w-none">
          <ReactMarkdown>{message}</ReactMarkdown>
          {image && (
            <div className="mt-2">
              <img
                src={image}
                alt="Shared image"
                className="max-w-[300px] rounded-lg cursor-zoom-in hover:opacity-90 transition-opacity"
                onClick={() => setShowImagePreview(true)}
              />
            </div>
          )}
        </div>
      </div>
      
      {showImagePreview && image && (
        <ImagePreview
          src={image}
          onClose={() => setShowImagePreview(false)}
        />
      )}
    </>
  );
}